<?php
namespace app\Home\controller;
use think\Controller;
use think\Request;
use think\Validate;
use think\Cache;
class Layui extends Controller
{
    public function index()
    {
        if(request()->isPost()){

        }
        return $this->fetch();
    }
}
